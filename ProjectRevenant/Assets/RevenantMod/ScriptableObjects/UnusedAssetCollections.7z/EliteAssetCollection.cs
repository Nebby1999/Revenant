﻿using RoR2;
using UnityEngine;
using System.Collections.Generic;
namespace RevenantMod
{
    [CreateAssetMenu(fileName = "EliteAssetCollection", menuName = "Revenant/AssetCollections/EliteAssetCollection")]
    public class EliteAssetCollection : EquipmentAssetCollection
    {
        public List<EliteDef> eliteDefs;
    }
}