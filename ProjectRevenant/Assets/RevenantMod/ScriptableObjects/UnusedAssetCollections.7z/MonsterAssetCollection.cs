﻿using RoR2;
using UnityEngine;
using MSU;
using System.Collections.Generic;
namespace RevenantMod
{
    [CreateAssetMenu(fileName = "MonsterAssetCollection", menuName = "Revenant/AssetCollections/MonsterAssetCollection")]
    public class MonsterAssetCollection : BodyAssetCollection
    {
        public MonsterCardProvider monsterCardProvider;
    }
}